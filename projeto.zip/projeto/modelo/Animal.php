<?php
class Animal {
 private $id;
 private $raca;
 private $nome;
 private $idade;
 private $dono;
 private $tel;


 public function save() {
 // salva animal no banco
 }

 public function update() {
 // atualiza animal no banco
 }

 public function remove() {
 // remove animal do banco
 }

 public function listAll() {
 // lista os animais do banco
 }

 
}

?>