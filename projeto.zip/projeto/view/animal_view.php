<?php
$animais = $_REQUEST['animais'];
?>;
<!DOCTYPE HTML PUBLIC "-//W3C//DTD HTML 4.01 Transitional//EN">
<html>
 <head>
 <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
 <title>Petshop softmakers</title>
 </head>
 <body>
 <table>
 <tr>
 <th>ID</th>
 <th>animal</th>
 </tr>
 <?php foreach ($animais as $animal): ?>
 <tr>
 <td><?php echo $animal->getId(); ?></td>
 <td><?php echo $animal->getRaça(); ?></td>
 <td><?php echo $animal->getNome(); ?></td>
 <td><?php echo $animal->getIdade(); ?></td>
 <td><?php echo $animal->getDono(); ?></td>
 <td><?php echo $animal->getTel(); ?></td>
 </tr>
 <?php endforeach; ?>
 </table>
 </body>
</html>
