<?php
require_once 'model/Animal.php';

class AnimalControle {

 public function listar() {
 $animal = new Animal();
 $animais = $animal->listAll();

 $_REQUEST['animais'] = $animais;

 require_once 'view/animal_view.php';
 }
}

?>